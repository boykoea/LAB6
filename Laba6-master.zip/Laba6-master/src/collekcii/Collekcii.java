package collekcii;

public class Collekcii {
public static void main(String[] args) {
        Array s = new Array();
        s.createArray();
        NewClass abcd = new NewClass();
        abcd.mapping();
        abcd.out(10);
        abcd.outall();
    }
}